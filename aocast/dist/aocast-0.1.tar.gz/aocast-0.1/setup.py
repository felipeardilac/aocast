from setuptools import setup
setup(name='aocast',
      version='0.1',
      description='ADAPTATIVE OPERATOR FORECAST',
      url='https://github.com/felipeardilac/aocast',
      author='Felipe Ardila Camelo',
      author_email='felipeardilac@gmail.com',
      license='MIT',
      packages=['aocast'])




